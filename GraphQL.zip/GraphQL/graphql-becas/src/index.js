import express from "express";
import { graphqlHTTP } from "express-graphql";
import { schema } from "./schema/typeDefs.js";
import { root } from "./resolvers/index.js";

const app = express();

// Middleware GraphQL
app.use(
  "/graphql",
  graphqlHTTP({
    schema,
    rootValue: root,
    graphiql: true, // Habilita el IDE web para pruebas en el navegador
    customFormatErrorFn: (err) => ({
      message: err.message,
      path: err.path,
    }),
  })
);

// Servidor
const PORT = 4000;
app.listen(PORT, () => {
  console.log(`🚀 Servidor GraphQL corriendo en: http://localhost:${PORT}/graphql`);
});
