export const estudiantes = [
{ id: "1", nombre: "Miguel", carrera: "Sistemas", promedio: 8.9, email: "miguel@uleam.edu" },
{ id: "2", nombre: "Ana", carrera: "Educación", promedio: 9.3, email: "ana@uleam.edu" },
{ id: "3", nombre: "Carlos", carrera: "Mecánica", promedio: 8.2, email: "carlos@uleam.edu" }
];

export const becas = [
{ id: "B1", nombre: "Beca Excelencia", monto: 1200, requisitoPromedio: 9.0
},
{ id: "B2", nombre: "Beca Alimentación", monto: 400, requisitoPromedio: 8.0
}
];

export const postulaciones = [
{ id: "P1", estudianteId: "2", becaId: "B1", estado: "APROBADA" },
{ id: "P2", estudianteId: "1", becaId: "B2", estado: "EN_REVISION" }
];
