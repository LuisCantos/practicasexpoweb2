import { buildSchema } from "graphql";

export const schema = buildSchema(`

  "Estudiante de la universidad"
  type Estudiante {
    id: ID!
    nombre: String!
    carrera: String!
    promedio: Float!
    email: String!
    postulaciones: [Postulacion!]
  }

  "Beca disponible"
  type Beca {
    id: ID!
    nombre: String!
    monto: Int!
    requisitoPromedio: Float!
    postulaciones: [Postulacion!]
  }

  "Postulación del estudiante a una beca"
  type Postulacion {
    id: ID!
    estudiante: Estudiante!
    beca: Beca!
    estado: String! # EN_REVISION | APROBADA | RECHAZADA
  }

  input EstudianteInput {
    nombre: String!
    carrera: String!
    promedio: Float!
    email: String!
  }

  input PostulacionInput {
    estudianteId: ID!
    becaId: ID!
  }

  input ActualizarEstudianteInput {
    id: ID!
    nombre: String
    carrera: String
    promedio: Float
    email: String
  }

  input ActualizarBecaInput {
    id: ID!
    nombre: String
    monto: Int
    requisitoPromedio: Float
  }

  type Query {
    hello: String!
    estudiantes: [Estudiante!]!
    becas: [Beca!]!
    postulaciones: [Postulacion!]!
    estudiante(id: ID!): Estudiante
    beca(id: ID!): Beca
    estudiantesPorCarrera(carrera: String!): [Estudiante!]!
    becasPorPromedio(min: Float!): [Beca!]!
  }

  type Mutation {
    # Crear registros
    crearEstudiante(input: EstudianteInput!): Estudiante!
    crearPostulacion(input: PostulacionInput!): Postulacion!
    crearBeca(nombre: String!, monto: Int!, requisitoPromedio: Float!): Beca!

    # Actualizar registros
    actualizarEstadoPostulacion(id: ID!, estado: String!): Postulacion!
    actualizarEstudiante(input: ActualizarEstudianteInput!): Estudiante!
    actualizarBeca(input: ActualizarBecaInput!): Beca!

    # Eliminar registros
    eliminarEstudiante(id: ID!): Boolean!
    eliminarBeca(id: ID!): Boolean!
  }
`);
