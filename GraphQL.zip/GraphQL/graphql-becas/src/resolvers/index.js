import { estudiantes, becas, postulaciones } from "../data/db.js";

// --- Funciones auxiliares ---
const emailOk = (e) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);
const byId = (arr, id) => arr.find((x) => x.id === id);

// --- Resolvers principales ---
export const root = {
  // -------- QUERIES --------
  hello: () => "¡API de Becas ULEAM con GraphQL!",

  estudiantes: () => estudiantes,
  becas: () => becas,
  postulaciones: () => postulaciones,

  estudiante: ({ id }) => byId(estudiantes, id) || null,
  beca: ({ id }) => byId(becas, id) || null,

  estudiantesPorCarrera: ({ carrera }) =>
    estudiantes.filter((e) =>
      e.carrera.toLowerCase().includes(carrera.toLowerCase())
    ),

  becasPorPromedio: ({ min }) =>
    becas.filter((b) => b.requisitoPromedio <= min),

  // -------- MUTATIONS --------
  crearEstudiante: ({ input }) => {
    if (!emailOk(input.email)) throw new Error("Email inválido");

    const dup = estudiantes.some((e) => e.email === input.email);
    if (dup) throw new Error("Ese email ya está registrado");

    const nuevo = { id: String(Date.now()), ...input };
    estudiantes.push(nuevo);
    return nuevo;
  },

  crearPostulacion: ({ input }) => {
    const est = byId(estudiantes, input.estudianteId);
    const beca = byId(becas, input.becaId);

    if (!est || !beca) throw new Error("Estudiante o beca inexistente");
    if (est.promedio < beca.requisitoPromedio)
      throw new Error("No cumple requisito de promedio");

    const dup = postulaciones.some(
      (p) => p.estudianteId === est.id && p.becaId === beca.id
    );
    if (dup) throw new Error("Ya postuló a esta beca");

    const nueva = {
      id: "P" + Date.now(),
      estudianteId: est.id,
      becaId: beca.id,
      estado: "EN_REVISION",
    };

    postulaciones.push(nueva);
    return nueva;
  },

  actualizarEstadoPostulacion: ({ id, estado }) => {
    const i = postulaciones.findIndex((p) => p.id === id);
    if (i === -1) throw new Error("Postulación no encontrada");

    postulaciones[i].estado = estado;
    return postulaciones[i];
  },

  crearBeca: ({ nombre, monto, requisitoPromedio }) => {
    const nueva = {
      id: `B${Date.now()}`,
      nombre,
      monto,
      requisitoPromedio,
    };
    becas.push(nueva);
    return nueva;
  },

  actualizarEstudiante: ({ input }) => {
    const index = estudiantes.findIndex((e) => e.id === input.id);
    if (index === -1) throw new Error("Estudiante no encontrado");

    if (input.email && !emailOk(input.email))
      throw new Error("Email inválido");

    estudiantes[index] = {
      ...estudiantes[index],
      ...input,
    };

    return estudiantes[index];
  },

  actualizarBeca: ({ input }) => {
    const index = becas.findIndex((b) => b.id === input.id);
    if (index === -1) throw new Error("Beca no encontrada");

    becas[index] = {
      ...becas[index],
      ...input,
    };

    return becas[index];
  },

  eliminarEstudiante: ({ id }) => {
    const index = estudiantes.findIndex((e) => e.id === id);
    if (index === -1) return false;

    // También elimina postulaciones relacionadas
    for (let i = postulaciones.length - 1; i >= 0; i--) {
      if (postulaciones[i].estudianteId === id) {
        postulaciones.splice(i, 1);
      }
    }

    estudiantes.splice(index, 1);
    return true;
  },

  eliminarBeca: ({ id }) => {
    const index = becas.findIndex((b) => b.id === id);
    if (index === -1) return false;

    // También elimina postulaciones relacionadas
    for (let i = postulaciones.length - 1; i >= 0; i--) {
      if (postulaciones[i].becaId === id) {
        postulaciones.splice(i, 1);
      }
    }

    becas.splice(index, 1);
    return true;
  },
};

// --- Campos anidados (resolvers adicionales) ---
export const typeResolvers = {
  Estudiante: {
    postulaciones: (parent) =>
      postulaciones.filter((p) => p.estudianteId === parent.id),
  },
  Beca: {
    postulaciones: (parent) =>
      postulaciones.filter((p) => p.becaId === parent.id),
  },
  Postulacion: {
    estudiante: (parent) => byId(estudiantes, parent.estudianteId),
    beca: (parent) => byId(becas, parent.becaId),
  },
};
